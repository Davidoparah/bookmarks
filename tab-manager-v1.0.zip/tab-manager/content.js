// Content script can remain empty as we don't need content script functionality
console.log('Tab Manager content script loaded'); 